<footer class="amp-wp-footer">
	<div>
		<h2><?php echo esc_html( wptexturize( $this->get( 'blog_name' ) ) ); ?></h2>
		<a href="#top" class="back-to-top"><?php esc_html_e( 'Back to top', 'bt_plugin' ); ?></a>
	</div>
</footer>
